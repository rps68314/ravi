'use client'

import { useState } from 'react'
import { useChat } from 'ai/react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ChatInterface() {
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    api: '/api/chat',
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle>Chat with your Excel data</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {messages.map((m) => (
            <div key={m.id} className="flex items-start space-x-2">
              <span className="font-bold">{m.role === 'user' ? 'You:' : 'AI:'}</span>
              <p>{m.content}</p>
            </div>
          ))}

          <form onSubmit={handleSubmit} className="flex space-x-2">
            <Input
              value={input}
              onChange={handleInputChange}
              placeholder="Ask about prices..."
            />
            <Button type="submit">Send</Button>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}

