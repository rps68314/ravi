'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import ChatInterface from './components/ChatInterface'

export default function Home() {
  const [excelUrl, setExcelUrl] = useState('')
  const [isUrlSubmitted, setIsUrlSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch('/api/process-excel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: excelUrl }),
    })
    if (response.ok) {
      setIsUrlSubmitted(true)
    } else {
      alert('Failed to process Excel file. Please check the URL and try again.')
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Excel ChatBot</h1>
      {!isUrlSubmitted ? (
        <Card>
          <CardHeader>
            <CardTitle>Enter Excel File URL</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="url"
                value={excelUrl}
                onChange={(e) => setExcelUrl(e.target.value)}
                placeholder="https://example.com/your-excel-file.xlsx"
                required
              />
              <Button type="submit">Submit</Button>
            </form>
          </CardContent>
        </Card>
      ) : (
        <ChatInterface />
      )}
    </div>
  )
}

