import { NextResponse } from 'next/server'
import { generateText } from 'ai'
import { openai } from '@ai-sdk/openai'
import { excelData } from '../process-excel/route'

export const runtime = 'nodejs'

export async function POST(req: Request) {
  const { messages } = await req.json()
  const lastMessage = messages[messages.length - 1].content

  const prompt = `
You are an AI assistant that helps users find information about items and their prices from an Excel database. 
The current data in the Excel file is:
${JSON.stringify(excelData, null, 2)}

Please answer the following question based on this data:
${lastMessage}

If the question cannot be answered based on the available data, please say so.
`

  try {
    const response = await generateText({
      model: openai('gpt-4o'),
      prompt: prompt,
    })

    return NextResponse.json({ content: response.text })
  } catch (error) {
    console.error('Error generating response:', error)
    return NextResponse.json({ error: 'Failed to generate response' }, { status: 500 })
  }
}

