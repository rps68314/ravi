import { NextResponse } from 'next/server'
import * as XLSX from 'xlsx'

let excelData: any[] = []

export async function POST(req: Request) {
  const { url } = await req.json()

  try {
    const response = await fetch(url)
    const arrayBuffer = await response.arrayBuffer()
    const data = new Uint8Array(arrayBuffer)
    const workbook = XLSX.read(data, { type: 'array' })

    const sheetName = workbook.SheetNames[0]
    const sheet = workbook.Sheets[sheetName]
    excelData = XLSX.utils.sheet_to_json(sheet)

    return NextResponse.json({ message: 'Excel file processed successfully' })
  } catch (error) {
    console.error('Error processing Excel file:', error)
    return NextResponse.json({ error: 'Failed to process Excel file' }, { status: 500 })
  }
}

export { excelData }

